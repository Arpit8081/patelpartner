<?php minti_pagination(); ?>
<p class="hidden"><?php posts_nav_link(); ?></p>